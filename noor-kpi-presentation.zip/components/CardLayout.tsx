import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Navigation from './Navigation';
import { SlideProps } from '../types';

interface CardLayoutProps extends SlideProps {
  children: React.ReactNode;
}

const CardLayout: React.FC<CardLayoutProps> = ({ children, ...navProps }) => {
  return (
    <div className="flex-1 bg-[#FDFBF7] rounded-[2rem] shadow-2xl overflow-hidden flex flex-col relative h-full">
      <div className="p-6 md:p-10 flex-1 overflow-y-auto relative no-scrollbar">
        <AnimatePresence mode="wait">
          <motion.div
            key={navProps.currentSlide}
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -10 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="h-full"
          >
            {children}
          </motion.div>
        </AnimatePresence>
      </div>
      
      <div className="bg-gray-50 border-t border-gray-100 z-10 relative">
        <Navigation {...navProps} theme="dark" />
      </div>
    </div>
  );
};

export default CardLayout;