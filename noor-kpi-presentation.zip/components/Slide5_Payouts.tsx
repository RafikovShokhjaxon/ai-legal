import React from 'react';
import { DollarSign, TrendingUp, Wallet } from 'lucide-react';

const Slide5_Payouts: React.FC = () => {
  return (
    <div className="flex flex-col h-full">
        
        <div className="flex items-center gap-3 mb-6">
            <div className="p-2.5 bg-green-100 rounded-xl text-green-600">
                <DollarSign size={24} />
            </div>
            <h2 className="text-xl md:text-2xl font-bold text-gray-800">
                Система выплат по KPI
            </h2>
        </div>

        {/* Payout Table */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden mb-6">
            <div className="bg-orange-600 text-white p-3.5 grid grid-cols-3 gap-2 font-bold text-sm">
                <div className="pl-4">Уровень выполнения</div>
                <div className="text-center">Премия</div>
                <div className="text-right pr-4">Итоговая зарплата</div>
            </div>
            <div className="divide-y divide-gray-100">
                <PayoutRow level="95–100%" bonus="2 000 000 сум" total="6 000 000 сум" levelColor="green" />
                <PayoutRow level="90–95%" bonus="1 600 000 сум" total="5 600 000 сум" levelColor="orange" />
                <PayoutRow level="85–90%" bonus="1 200 000 сум" total="5 200 000 сум" levelColor="yellow" />
                <PayoutRow level="< 85%" bonus="0 сум" total="4 000 000 сум" levelColor="red" />
            </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <SummaryCard 
                title="Максимальная премия"
                value="2 000 000 сум (50%)"
                icon={<TrendingUp className="text-white" size={20} />}
                bg="bg-emerald-500"
                />
                <SummaryCard 
                title="Базовый оклад"
                value="4 000 000 сум"
                icon={<Wallet className="text-white" size={20} />}
                bg="bg-orange-600"
                />
        </div>
    </div>
  );
};

const PayoutRow = ({ level, bonus, total, levelColor }: { level: string, bonus: string, total: string, levelColor: string }) => {
    const badgeStyles = {
        green: 'bg-green-100 text-green-700',
        orange: 'bg-orange-100 text-orange-700',
        yellow: 'bg-yellow-100 text-yellow-700',
        red: 'bg-red-100 text-red-700',
    };
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const badgeStyle = (badgeStyles as any)[levelColor];

    return (
        <div className="p-4 grid grid-cols-3 gap-2 items-center hover:bg-gray-50 transition-colors">
            <div className="flex justify-start">
                <span className={`px-2.5 py-1 rounded-full text-xs font-extrabold tracking-wide ${badgeStyle}`}>
                    {level}
                </span>
            </div>
            <div className="text-center font-semibold text-gray-700 text-sm">{bonus}</div>
            <div className="text-right pr-4 font-bold text-gray-900 text-sm">{total}</div>
        </div>
    );
}

const SummaryCard = ({ title, value, icon, bg }: { title: string, value: string, icon: React.ReactNode, bg: string }) => (
    <div className={`${bg} rounded-xl p-5 shadow-md flex flex-col relative overflow-hidden group`}>
        <div className="absolute right-0 top-0 p-6 opacity-10 transform translate-x-4 -translate-y-4 scale-150 group-hover:scale-125 transition-transform duration-500">
            {icon}
        </div>
        <div className="flex items-center gap-2 mb-1 text-white/90">
             {icon}
             <span className="font-bold text-xs uppercase tracking-wider opacity-90">{title}</span>
        </div>
        <div className="text-2xl font-extrabold text-white tracking-tight">
            {value}
        </div>
    </div>
);

export default Slide5_Payouts;