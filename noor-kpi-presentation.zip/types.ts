export interface SlideProps {
  onNext: () => void;
  onPrev: () => void;
  currentSlide: number;
  totalSlides: number;
}
