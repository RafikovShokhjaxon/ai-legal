import React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface NavigationProps {
  onNext: () => void;
  onPrev: () => void;
  currentSlide: number;
  totalSlides: number;
  theme?: 'light' | 'dark'; // 'light' means light text on dark background (Slide 1), 'dark' means dark text (Slide 2-5)
}

const Navigation: React.FC<NavigationProps> = ({ 
  onNext, 
  onPrev, 
  currentSlide, 
  totalSlides,
  theme = 'dark' 
}) => {
  const isLight = theme === 'light';

  return (
    <div className="flex items-center justify-between w-full mt-auto pt-4 pb-4 px-6 md:px-10">
      <button
        onClick={onPrev}
        disabled={currentSlide === 0}
        className={`flex items-center px-5 py-2.5 rounded-xl font-semibold text-sm transition-all ${
          isLight 
            ? 'bg-white/20 text-white hover:bg-white/30 disabled:opacity-0' 
            : 'bg-orange-500 text-white hover:bg-orange-600 disabled:opacity-0 shadow-md'
        }`}
      >
        <ChevronLeft className="w-4 h-4 mr-1.5" />
        Назад
      </button>

      <div className="flex space-x-2">
        {Array.from({ length: totalSlides }).map((_, index) => (
          <div
            key={index}
            className={`h-2.5 rounded-full transition-all duration-300 ${
              currentSlide === index 
                ? (isLight ? 'w-8 bg-white' : 'w-8 bg-orange-500') 
                : (isLight ? 'w-2.5 bg-white/40' : 'w-2.5 bg-gray-300')
            }`}
          />
        ))}
      </div>

      <button
        onClick={onNext}
        disabled={currentSlide === totalSlides - 1}
        className={`flex items-center px-5 py-2.5 rounded-xl font-semibold text-sm transition-all ${
          isLight 
            ? 'bg-white text-orange-600 hover:bg-white/90 disabled:opacity-0 shadow-lg' 
            : 'bg-orange-500 text-white hover:bg-orange-600 disabled:opacity-0 shadow-md'
        }`}
      >
        Далее
        <ChevronRight className="w-4 h-4 ml-1.5" />
      </button>
    </div>
  );
};

export default Navigation;