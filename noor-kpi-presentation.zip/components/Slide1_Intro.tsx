import React from 'react';
import { TrendingUp, Award, Phone } from 'lucide-react';
import { motion } from 'framer-motion';
import Navigation from './Navigation';
import { SlideProps } from '../types';

const Slide1_Intro: React.FC<SlideProps> = (props) => {
  return (
    <div className="flex flex-col h-full w-full bg-[#EA580C] text-white p-6 md:p-10 relative overflow-hidden">
      
      {/* Decorative Background Elements */}
      <div className="absolute top-[-20%] left-[-10%] w-[50vh] h-[50vh] bg-orange-500 rounded-full opacity-30 blur-3xl" />
      <div className="absolute bottom-[-20%] right-[-10%] w-[60vh] h-[60vh] bg-orange-400 rounded-full opacity-20 blur-3xl" />

      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5, ease: "easeInOut" }}
        className="flex-1 flex flex-col items-center justify-center text-center z-10"
      >
        {/* Logo Area */}
        <div className="mb-8 relative">
            <div className="w-40 h-40 bg-white/10 backdrop-blur-sm rounded-3xl flex items-center justify-center shadow-xl border border-white/20">
                <div className="relative">
                    <h1 className="text-5xl font-extrabold tracking-tighter">noor</h1>
                    <span className="absolute -top-2 -right-4 text-[10px] font-bold border-[1.5px] border-white rounded-full w-4 h-4 flex items-center justify-center">R</span>
                    <div className="w-full h-1 bg-white mt-1 rounded-full"></div>
                </div>
            </div>
        </div>

        <h2 className="text-2xl md:text-4xl font-light mb-10 max-w-2xl leading-tight">
          Система KPI для операторов <br/>
          <span className="font-bold tracking-tight">Call Center</span>
        </h2>

        <div className="flex flex-wrap justify-center gap-6 md:gap-12 mb-14">
          <FeatureIcon icon={<TrendingUp size={28} />} label="Эффективность" />
          <FeatureIcon icon={<Award size={28} />} label="Качество" />
          <FeatureIcon icon={<Phone size={28} />} label="Сервис" />
        </div>

        <p className="text-base md:text-lg font-medium opacity-80 tracking-wide">
          Комплексная система оценки и мотивации персонала
        </p>
      </motion.div>

      <div className="w-full max-w-4xl mx-auto rounded-3xl bg-white/10 backdrop-blur-md">
        <Navigation {...props} theme="light" />
      </div>
    </div>
  );
};

const FeatureIcon = ({ icon, label }: { icon: React.ReactNode, label: string }) => (
  <div className="flex flex-col items-center gap-3 group cursor-default">
    <div className="w-16 h-16 rounded-2xl bg-white/20 flex items-center justify-center backdrop-blur-sm group-hover:bg-white/30 transition-all duration-300 shadow-lg border border-white/10">
      {icon}
    </div>
    <span className="text-base font-semibold tracking-wide">{label}</span>
  </div>
);

export default Slide1_Intro;