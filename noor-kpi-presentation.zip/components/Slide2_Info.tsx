import React from 'react';
import { Calendar, Phone, Clock, DollarSign, Wallet } from 'lucide-react';

const Slide2_Info: React.FC = () => {
  return (
    <div className="flex flex-col h-full">
      <h2 className="text-xl md:text-2xl font-bold text-orange-700 mb-6 tracking-tight">
        Основная информация
      </h2>

      <div className="space-y-4">
        
        {/* Schedule Section */}
        <div className="bg-white rounded-xl p-5 shadow-sm border border-orange-100 relative overflow-hidden group hover:shadow-md transition-shadow">
            <div className="absolute left-0 top-0 w-1 h-full bg-orange-500"></div>
            <div className="flex items-center gap-3 mb-3 text-gray-800">
                <div className="p-1.5 bg-orange-100 rounded-lg text-orange-600">
                    <Calendar size={20} />
                </div>
                <span className="text-lg font-bold">График работы</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <ScheduleCard title="День - 1 смена" time="с 9:00 до 18:00" bg="bg-yellow-50" border="border-yellow-200" />
                <ScheduleCard title="День - 2 смена" time="с 11:00 до 20:00" bg="bg-orange-50" border="border-orange-200" />
                <ScheduleCard title="Ночь" time="с 19:00 до 4:00" bg="bg-red-50" border="border-red-200" />
            </div>
        </div>

        {/* Metrics Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <InfoCard 
                icon={<Phone className="text-green-600" size={20} />}
                title="Средняя нагрузка"
                value="Минимум 70 звонков в день"
                color="green"
            />
             <InfoCard 
                icon={<Clock className="text-purple-600" size={20} />}
                title="Длительность звонка"
                value="В среднем 3 минуты"
                color="purple"
            />
        </div>

        {/* Salary Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
             <InfoCard 
                icon={<Wallet className="text-orange-600" size={20} />}
                title="Оклад оператора"
                value="4 000 000 сум"
                isMoney
                color="orange"
            />
             <InfoCard 
                icon={<DollarSign className="text-teal-600" size={20} />}
                title="Максимальная премия"
                value="2 000 000 сум (50%)"
                isMoney
                color="teal"
            />
        </div>

      </div>
    </div>
  );
};

const ScheduleCard = ({ title, time, bg, border }: { title: string, time: string, bg: string, border: string }) => (
    <div className={`${bg} ${border} border rounded-lg p-3 flex flex-col justify-center h-20`}>
        <div className="text-gray-900 font-bold text-sm mb-1">{title}</div>
        <div className="text-gray-600 text-sm font-medium">{time}</div>
    </div>
);

const InfoCard = ({ icon, title, value, isMoney = false, color }: { icon: React.ReactNode, title: string, value: string, isMoney?: boolean, color: string }) => {
    const colorClasses = {
        green: 'bg-green-50 border-green-200 border-l-green-500',
        purple: 'bg-purple-50 border-purple-200 border-l-purple-500',
        orange: 'bg-orange-50 border-orange-200 border-l-orange-500',
        teal: 'bg-teal-50 border-teal-200 border-l-teal-500',
    };

    const selectedColorClass = (colorClasses as any)[color] || colorClasses.orange;

    return (
        <div className={`p-5 rounded-xl shadow-sm border border-l-4 ${selectedColorClass} flex items-center gap-4 transition-transform hover:-translate-y-0.5`}>
            <div className={`p-2.5 rounded-full bg-white shadow-sm`}>
                {icon}
            </div>
            <div>
                <div className="text-gray-500 text-xs font-bold mb-0.5 uppercase tracking-wider">{title}</div>
                <div className={`font-extrabold text-gray-800 ${isMoney ? 'text-xl' : 'text-lg'}`}>{value}</div>
            </div>
        </div>
    );
}

export default Slide2_Info;