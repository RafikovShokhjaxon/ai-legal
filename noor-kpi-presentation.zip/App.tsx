import React, { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import Slide1_Intro from './components/Slide1_Intro';
import Slide2_Info from './components/Slide2_Info';
import Slide3_KPI_1 from './components/Slide3_KPI_1';
import Slide4_KPI_2 from './components/Slide4_KPI_2';
import Slide5_Payouts from './components/Slide5_Payouts';
import CardLayout from './components/CardLayout';

const App: React.FC = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const totalSlides = 5;

  const handleNext = () => {
    if (currentSlide < totalSlides - 1) {
      setCurrentSlide(currentSlide + 1);
    }
  };

  const handlePrev = () => {
    if (currentSlide > 0) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  const slideProps = {
    onNext: handleNext,
    onPrev: handlePrev,
    currentSlide,
    totalSlides
  };

  // Logic to determine what to render
  const isIntro = currentSlide === 0;

  return (
    <div className="w-full h-screen flex items-center justify-center bg-[#EA580C] overflow-hidden">
      <div className="w-full h-full max-w-7xl mx-auto md:h-[90vh] md:rounded-[3rem] overflow-hidden bg-[#EA580C] relative shadow-2xl">
        
        {/* Render Intro Slide separately as it has a unique layout */}
        {isIntro && (
            <motion.div 
                key="intro"
                className="w-full h-full"
                exit={{ opacity: 0 }}
                transition={{ duration: 0.4 }}
            >
                <Slide1_Intro {...slideProps} />
            </motion.div>
        )}

        {/* Render Card Layout for all other slides. 
            The Layout stays mounted, only children change. 
        */}
        {!isIntro && (
            <motion.div 
                key="card-layout"
                className="w-full h-full p-4"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4 }}
            >
                <CardLayout {...slideProps}>
                    {currentSlide === 1 && <Slide2_Info />}
                    {currentSlide === 2 && <Slide3_KPI_1 />}
                    {currentSlide === 3 && <Slide4_KPI_2 />}
                    {currentSlide === 4 && <Slide5_Payouts />}
                </CardLayout>
            </motion.div>
        )}

      </div>
    </div>
  );
};

export default App;