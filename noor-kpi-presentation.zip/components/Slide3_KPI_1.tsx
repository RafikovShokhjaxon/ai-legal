import React from 'react';
import { Zap, Award, TrendingUp } from 'lucide-react';

const Slide3_KPI_1: React.FC = () => {
  return (
    <div className="flex flex-col h-full">
        {/* KPI 1 */}
        <KPICard 
            icon={<Zap className="text-red-500" />}
            title="Скорость реакции (SLA)"
            percentage="30%"
            color="red"
        >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <MetricItem label="Звонки" value="ответ до 20 сек" subtext="Цель: 85% звонков" />
                <MetricItem label="Чаты" value="ответ до 3 минут" subtext="Цель: 90% обращений" />
            </div>
        </KPICard>

        {/* KPI 2 */}
        <KPICard 
            icon={<Award className="text-orange-500" />}
            title="Качество работы"
            percentage="30%"
            color="orange"
        >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <MetricItem label="Оценка QA" value="≥ 90%" />
                <div className="bg-gray-50 p-3 rounded-lg border border-gray-100">
                    <div className="font-bold text-gray-800 mb-0.5 text-sm">Ошибки</div>
                    <div className="text-gray-600 text-sm font-medium">≤ 2 в месяц</div>
                    <div className="text-red-500 text-[10px] font-bold mt-1 uppercase tracking-wide">Критические ошибки запрещены</div>
                </div>
            </div>
        </KPICard>

            {/* KPI 3 */}
            <KPICard 
            icon={<TrendingUp className="text-green-500" />}
            title="Продуктивность"
            percentage="20%"
            color="green"
        >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <MetricItem label="Нагрузка" value="Минимум 70 звонков/день" />
                <MetricItem label="Исходящие задачи" value="100% выполнение" subtext="Обязательная цель" />
            </div>
        </KPICard>
    </div>
  );
};

const KPICard = ({ icon, title, percentage, children, color }: { icon: React.ReactNode, title: string, percentage: string, children?: React.ReactNode, color: string }) => {
    const borderColors = {
        red: 'border-l-red-500',
        orange: 'border-l-orange-500',
        green: 'border-l-green-500'
    };
    
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const borderColor = (borderColors as any)[color] || 'border-l-gray-500';

    return (
        <div className={`mb-4 bg-white rounded-xl p-5 shadow-sm border border-gray-100 border-l-[4px] ${borderColor}`}>
            <div className="flex justify-between items-center mb-4">
                <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${color === 'red' ? 'bg-red-100' : color === 'orange' ? 'bg-orange-100' : 'bg-green-100'}`}>
                        {React.cloneElement(icon as React.ReactElement, { size: 20 })}
                    </div>
                    <h3 className="text-lg font-bold text-gray-800">{title}</h3>
                </div>
                <div className={`px-3 py-1 rounded-full font-extrabold text-xs ${color === 'red' ? 'bg-red-100 text-red-600' : color === 'orange' ? 'bg-orange-100 text-orange-600' : 'bg-green-100 text-green-600'}`}>
                    {percentage}
                </div>
            </div>
            <div className="pl-0 md:pl-12">
                {children}
            </div>
        </div>
    );
};

const MetricItem = ({ label, value, subtext }: { label: string, value: string, subtext?: string }) => (
    <div className="bg-gray-50 p-3 rounded-lg border border-gray-100">
        <div className="font-bold text-gray-800 text-sm mb-0.5">{value}</div>
        <div className="text-gray-500 text-xs font-medium">{label}</div>
        {subtext && <div className="text-orange-600 text-[10px] mt-1 font-bold uppercase">{subtext}</div>}
    </div>
);

export default Slide3_KPI_1;